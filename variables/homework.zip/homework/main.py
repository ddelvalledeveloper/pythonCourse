# Python is easy - Variables homework
"""
In this file, we will define information about a musician 
and one of their songs using variables.
"""

# Name of the artist
Artist = "Marilyn Manson"
# Music genre
Genre = "Rock"
# Music genre
SubGenre = "Industrial"
# My favorite song
FavoriteSong = "Man That You Fear"
# Total duration of my favorite song (Seconds)
DurationInSeconds = 370
# Total duration of my favorite song (Minutes)
DurationInMinutes = 6.16

print(Artist)
print(Genre)
print(SubGenre)
print(FavoriteSong)
print(DurationInSeconds)
print(DurationInMinutes)